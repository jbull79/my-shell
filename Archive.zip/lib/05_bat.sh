#!/usr/bin/env bash
# shellcheck shell=bash
set -euo pipefail

# Load shared functions
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/00_utils.sh"

info "Configuring bat syntax highlighting and themes..."

BAT_REPO="${BAT_REPO:-$HOME/git-local/bat}"
BAT_CONFIG_DIR="${BAT_CONFIG_DIR:-$HOME/.config/bat}"
BAT_CACHE_DIR="${BAT_CACHE_DIR:-$HOME/.cache/bat}"
BAT_DEFAULT_THEME="${BAT_DEFAULT_THEME:-TwoDark}"

mkdir -p "$BAT_CONFIG_DIR" "$BAT_CACHE_DIR"

# Clone or update the bat repo
if [ -d "$BAT_REPO" ]; then
  info "Updating bat repository..."
  run "git -C \"$BAT_REPO\" pull --quiet"
else
  info "Cloning bat assets..."
  run "git clone https://github.com/sharkdp/bat.git \"$BAT_REPO\" --quiet"
fi

# Build syntax & theme cache
info "Rebuilding bat syntax and theme cache..."
run "bat cache --clear"
run "bat cache --build"

# Apply default theme in config file
BAT_CONF_FILE="$BAT_CONFIG_DIR/config"

if ! grep -q "BAT_THEME" "$BAT_CONF_FILE" 2>/dev/null; then
cat <<EOF > "$BAT_CONF_FILE"
# ========================================================
# bat Configuration (Auto-generated)
# ========================================================
--theme="$BAT_DEFAULT_THEME"
--paging=auto
--style=plain,changes,header,grid
EOF
fi

success "bat syntax and theme configuration complete."