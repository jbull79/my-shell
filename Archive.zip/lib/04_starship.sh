#!/usr/bin/env bash
# shellcheck shell=bash
set -euo pipefail

# Load shared functions
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/00_utils.sh"

STARSHIP_DIR="${STARSHIP_DIR:-$HOME/.config}"
STARSHIP_DEFAULT_THEME="${STARSHIP_DEFAULT_THEME:-pastel-powerline}"
STARSHIP_GIT_THEME="${STARSHIP_GIT_THEME:-tokyo-night}"
STARSHIP_DEFAULT_CONF="$STARSHIP_DIR/starship_default.toml"
STARSHIP_GIT_CONF="$STARSHIP_DIR/starship_git.toml"
ZSHRC="${ZSHRC:-$HOME/.zshrc}"

info "Configuring Starship prompt..."
mkdir -p "$STARSHIP_DIR"

# Always overwrite preset configs to start clean
starship preset "$STARSHIP_DEFAULT_THEME" > "$STARSHIP_DEFAULT_CONF"
starship preset "$STARSHIP_GIT_THEME" > "$STARSHIP_GIT_CONF"

INSTALL_AWS_CLI="${INSTALL_AWS_CLI:-true}"
if [ "$INSTALL_AWS_CLI" = true ]; then
  AWS_CFG="$HOME/.aws/config"

  # Detect AWS profiles
  if [ -f "$AWS_CFG" ]; then
    mapfile -t AWS_PROFILES < <(grep '^\[profile ' "$AWS_CFG" | sed -E 's/^\[profile (.*)\]/\1/')
  else
    AWS_PROFILES=("default")
  fi
  [ ${#AWS_PROFILES[@]} -eq 0 ] && AWS_PROFILES=("default")

  # Build alias and style sections without duplicates
  declare -A alias_map style_map
  for profile in "${AWS_PROFILES[@]}"; do
    case "$profile" in
      prod|production) alias_map["$profile"]="production"; style_map["production"]="bold red" ;;
      dev|development) alias_map["$profile"]="development"; style_map["development"]="bold green" ;;
      staging) alias_map["$profile"]="staging"; style_map["staging"]="bold yellow" ;;
      sandbox) alias_map["$profile"]="sandbox"; style_map["sandbox"]="bold blue" ;;
      *) alias_map["$profile"]="$profile"; style_map["$profile"]="bold cyan" ;;
    esac
  done

  append_aws_block() {
    local file="$1"
    # Remove old block
    sed -i.bak '/# --- AWS BLOCK BEGIN ---/,/# --- AWS BLOCK END ---/d' "$file"
    rm -f "${file}.bak"

    {
      echo ""
      echo "# --- AWS BLOCK BEGIN ---"
      echo "# --- AWS Profile Indicator (Auto-generated) ---"
      echo "[aws]"
      echo 'symbol = "☁️ "'
      echo 'style = "bold yellow"'
      echo 'format = "on [$symbol$profile]($style) "'
      echo 'disabled = false'
      echo ""
      echo "[aws.profile_aliases]"
      for k in "${!alias_map[@]}"; do
        echo "$k = \"${alias_map[$k]}\""
      done
      echo ""
      echo "[aws.style_map]"
      for k in "${!style_map[@]}"; do
        echo "$k = \"${style_map[$k]}\""
      done
      echo "# --- AWS BLOCK END ---"
    } >> "$file"
  }

  append_aws_block "$STARSHIP_DEFAULT_CONF"
  append_aws_block "$STARSHIP_GIT_CONF"
fi

# Add Zsh hook if missing
if ! grep -q "starship_preexec" "$ZSHRC"; then
  cat <<'EOF' >> "$ZSHRC"

# --- Dynamic Starship Theme Switch ---
starship_preexec() {
  if git rev-parse --is-inside-work-tree &>/dev/null; then
    export STARSHIP_CONFIG="$HOME/.config/starship_git.toml"
  else
    export STARSHIP_CONFIG="$HOME/.config/starship_default.toml"
  fi
}
autoload -Uz add-zsh-hook
add-zsh-hook precmd starship_preexec
eval "$(starship init zsh)"
EOF
fi

success "Starship configured (auto theme + AWS indicator)."