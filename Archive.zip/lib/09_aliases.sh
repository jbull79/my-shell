#!/usr/bin/env bash
# shellcheck shell=bash
set -euo pipefail

# Load shared functions
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/00_utils.sh"

ZSHRC="${ZSHRC:-$HOME/.zshrc}"

info "Adding common CLI aliases..."

# Only add once
if ! grep -q "### COMMON ALIASES START" "$ZSHRC" 2>/dev/null; then
cat <<EOF >> "$ZSHRC"

### COMMON ALIASES START ###
# --- CLI Aliases ---
alias cat="bat"
alias du="duf"
alias cd="z"
alias ll="ls -alsh"
alias lg="lazygit"

# --- Datadog ---
alias ddm="dog monitor show_all"
alias ddlog="datadog-ci logs upload"

# --- AWS Helpers ---
alias aws-whoami='echo "AWS_PROFILE=\$AWS_PROFILE" && aws sts get-caller-identity --output json 2>/dev/null || echo "Not logged in or invalid credentials."'

### COMMON ALIASES END ###
EOF
  success "Aliases added to $ZSHRC"
else
  info "Aliases already present in $ZSHRC — skipping."
fi