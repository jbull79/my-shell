#!/usr/bin/env bash
# shellcheck shell=bash
set -euo pipefail

    info()    { [ "${QUIET:-false}" = true ] || echo -e "\033[1;34m[INFO]\033[0m $*"; }
    warn()    { echo -e "\033[1;33m[WARN]\033[0m $*"; }
    error()   { echo -e "\033[1;31m[ERROR]\033[0m $*"; }
    success() { echo -e "\033[1;32m[SUCCESS]\033[0m $*"; }

    run() {
      if [ "${DRY_RUN:-false}" = true ]; then
        echo "[DRY-RUN] $*"
      else
        eval "$@"
      fi
    }

    backup_file() {
      local file="$1"
      local dest="${BACKUP_DIR:-$HOME/.setup_backups/adhoc_$(date +%Y%m%d_%H%M%S)}"
      if [ -f "$file" ]; then
        mkdir -p "$dest"
        cp "$file" "$dest/$(basename "$file").bak"
        info "Backed up $file → $dest"
      fi
    }
