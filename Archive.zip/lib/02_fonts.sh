#!/usr/bin/env bash
# shellcheck shell=bash
set -euo pipefail

# Load shared functions
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/00_utils.sh"

info "Ensuring Meslo Nerd Font is installed..."

# Check if the font is already installed
if [[ "$OSTYPE" == "darwin"* ]]; then
  if ! ls ~/Library/Fonts /Library/Fonts 2>/dev/null | grep -qi "MesloLGS NF"; then
    info "Installing Meslo Nerd Font (macOS)..."
    # Try direct install first, fallback to cask if needed
    if brew search font-meslo-lg-nerd-font | grep -q "font-meslo-lg-nerd-font"; then
      run "brew install --cask font-meslo-lg-nerd-font"
    else
      warn "Font not found in core taps — fetching manually from Nerd Fonts repo..."
      FONT_TMP_DIR="$(mktemp -d)"
      curl -fsSL -o "$FONT_TMP_DIR/MesloLGS_NF.zip" \
        "https://github.com/ryanoasis/nerd-fonts/releases/latest/download/Meslo.zip"
      unzip -q "$FONT_TMP_DIR/MesloLGS_NF.zip" -d "$FONT_TMP_DIR"
      cp "$FONT_TMP_DIR"/*.ttf ~/Library/Fonts/
      rm -rf "$FONT_TMP_DIR"
    fi
  else
    info "Meslo Nerd Font already installed."
  fi
else
  # Linux font install path
  if ! fc-list | grep -qi 'MesloLGS NF'; then
    info "Installing Meslo Nerd Font (Linux)..."
    run "brew install --cask font-meslo-lg-nerd-font || true"
  else
    info "Meslo Nerd Font already installed."
  fi
fi

success "Installed Meslo Nerd Font."