#!/usr/bin/env bash
# shellcheck shell=bash
set -euo pipefail

# Load shared functions
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/00_utils.sh"

    ZSHRC="${ZSHRC:-$HOME/.zshrc}"

    if [ ! -d "$HOME/.oh-my-zsh" ]; then
      info "Installing Oh My Zsh..."
      run 'RUNZSH=no CHSH=no sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"'
    else
      info "Oh My Zsh already installed."
    fi

    for dir in "${GIT_WORK_DIR:-$HOME/git}" "${GIT_LOCAL_DIR:-$HOME/git-local}" "${SSH_DIR:-$HOME/.ssh}" "${GPG_DIR:-$HOME/.gnupg}"; do
      run "mkdir -p $dir && chmod 700 $dir"
    done

    success "Zsh base configured."
