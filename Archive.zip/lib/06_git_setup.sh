#!/usr/bin/env bash
# shellcheck shell=bash
set -euo pipefail

# Load shared functions
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/00_utils.sh"

info "Configuring Git and SSH..."

SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
GPG_DIR="${GPG_DIR:-$HOME/.gnupg}"
GITCONFIG="${GITCONFIG:-$HOME/.gitconfig}"
BACKUP_BASE="${BACKUP_BASE:-$HOME/.setup_backups}"
BACKUP_DIR="${BACKUP_DIR:-$BACKUP_BASE/backup_$(date +%Y%m%d_%H%M%S)}"
mkdir -p "$BACKUP_DIR"

# Backup existing config
backup_file "$GITCONFIG"

# SSH key generation
if [ ! -f "$SSH_KEY" ]; then
  info "Generating new SSH key..."
  run "ssh-keygen -t ed25519 -C \"$(git config user.email || whoami)@$(hostname)\" -f \"$SSH_KEY\" -N ''"
else
  info "SSH key already exists: $SSH_KEY"
fi

# Ensure permissions
run "chmod 700 ~/.ssh"
run "chmod 600 $SSH_KEY"

# Global git configuration (interactive optional)
read -r -p "Would you like to update your global Git config (name/email/signing)? (y/N): " UPDATE_GITCFG
if [[ "$UPDATE_GITCFG" =~ ^[Yy]$ ]]; then
  read -r -p "Name: " GIT_NAME
  read -r -p "Email: " GIT_EMAIL
  git config --global user.name "$GIT_NAME"
  git config --global user.email "$GIT_EMAIL"

  # Optionally enable GPG signing
  read -r -p "Enable GPG commit signing? (y/N): " ENABLE_SIGN
  if [[ "$ENABLE_SIGN" =~ ^[Yy]$ ]]; then
    read -r -p "Enter your GPG key ID: " GPG_KEY
    git config --global user.signingkey "$GPG_KEY"
    git config --global commit.gpgsign true
  fi
fi

# Create .gitconfig extras if missing
if ! grep -q "\[alias\]" "$GITCONFIG" 2>/dev/null; then
cat <<EOF >> "$GITCONFIG"

[alias]
  st = status
  co = checkout
  br = branch
  cm = commit
  df = diff
  lg = log --oneline --graph --decorate --all

[color]
  ui = auto
EOF
fi

success "Git configuration complete."