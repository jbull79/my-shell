    #!/usr/bin/env bash
    # shellcheck shell=bash
    set -euo pipefail

    # Load shared functions
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    source "$SCRIPT_DIR/00_utils.sh"

    echo -e "\033[1;36m📦 Backup directory:\033[0m ${BACKUP_DIR:-$HOME/.setup_backups}"
    echo -e "\033[1;32m✅ Setup complete!\033[0m"
    echo -e "\033[1;36m💡 Font:\033[0m MesloLGS NF (set in terminal preferences)"
    echo ""
    echo "You can verify glyph support with:"
    echo "  echo '         '"
