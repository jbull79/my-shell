\
    #!/usr/bin/env bash
    # shellcheck shell=bash
    [[ "${BASH_SOURCE[0]}" == "$0" ]] && { echo "Source via install.sh"; exit 1; }

    # Template for new modules
    info "Running template module..."
    # run "brew install example"
    success "Template module finished."
