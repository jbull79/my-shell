#!/usr/bin/env bash
# shellcheck shell=bash
set -euo pipefail

# Load shared functions
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/00_utils.sh"

INSTALL_AWS_CLI="${INSTALL_AWS_CLI:-true}"
AWS_CONFIG_DIR="${AWS_CONFIG_DIR:-$HOME/.aws}"
AWS_BACKUP_DIR="${BACKUP_BASE:-$HOME/.setup_backups}/backup_$(date +%Y%m%d_%H%M%S)"
AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-us-east-1}"
AWS_DEFAULT_OUTPUT="${AWS_DEFAULT_OUTPUT:-json}"

if [ "$INSTALL_AWS_CLI" = true ]; then
  info "Installing AWS CLI (if not present)..."
  if ! command -v aws &>/dev/null; then
    run "brew install awscli"
  else
    info "AWS CLI already installed."
  fi

  mkdir -p "$AWS_CONFIG_DIR"
  backup_file "$AWS_CONFIG_DIR/config"
  backup_file "$AWS_CONFIG_DIR/credentials"
  info "Backed up existing AWS config → $AWS_BACKUP_DIR/aws_backup_$(date +%Y%m%d_%H%M%S)"

  echo ""
  echo "───────────────────────────────────────────────"
  echo "☁️  AWS CLI Profile Setup"
  echo "───────────────────────────────────────────────"
  echo ""

  read -r -p "Enter AWS profile names separated by spaces (default: 'dev prod'): " PROFILE_INPUT
  if [ -z "$PROFILE_INPUT" ]; then
    AWS_PROFILES=("dev" "prod")
  else
    read -ra AWS_PROFILES <<< "$PROFILE_INPUT"
  fi
  info "Profiles to configure: ${AWS_PROFILES[*]}"

  read -r -p "Do you want to provide valid AWS account details now? (y/N): " PROVIDE_DETAILS

  for PROFILE in "${AWS_PROFILES[@]}"; do
    echo ""
    info "Configuring profile: $PROFILE"

    if [[ "$PROVIDE_DETAILS" =~ ^[Yy]$ ]]; then
      read -r -p "AWS region for '$PROFILE' (default: $AWS_DEFAULT_REGION): " REGION
      REGION=${REGION:-$AWS_DEFAULT_REGION}
      read -r -p "Output format (default: $AWS_DEFAULT_OUTPUT): " OUTPUT
      OUTPUT=${OUTPUT:-$AWS_DEFAULT_OUTPUT}
      read -r -p "Access Key ID for '$PROFILE': " ACCESS_KEY
      read -r -p "Secret Access Key for '$PROFILE': " SECRET_KEY
    else
      REGION="$AWS_DEFAULT_REGION"
      OUTPUT="$AWS_DEFAULT_OUTPUT"
      ACCESS_KEY="DUMMYKEY-${PROFILE^^}"
      SECRET_KEY="DUMMYSECRET-${PROFILE^^}"
    fi

    mkdir -p "$AWS_CONFIG_DIR"

    # Config file
    {
      echo "[profile $PROFILE]"
      echo "region = $REGION"
      echo "output = $OUTPUT"
    } >> "$AWS_CONFIG_DIR/config"

    # Credentials file
    {
      echo "[$PROFILE]"
      echo "aws_access_key_id = $ACCESS_KEY"
      echo "aws_secret_access_key = $SECRET_KEY"
    } >> "$AWS_CONFIG_DIR/credentials"

  done

  # Optional alias to switch profiles quickly
  if ! grep -q "alias aws-switch" "$ZSHRC" 2>/dev/null; then
cat <<EOF >> "$ZSHRC"

# --- AWS Profile Switch Helper ---
aws-switch() {
  if [ -z "\$1" ]; then
    echo "Usage: aws-switch <profile>"
    return 1
  fi
  export AWS_PROFILE="\$1"
  echo "Switched to AWS profile: \$AWS_PROFILE"
}
EOF
  fi

  success "AWS CLI configured successfully."
else
  info "Skipping AWS CLI installation."
fi