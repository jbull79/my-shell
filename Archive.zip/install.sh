#!/usr/bin/env bash
# =============================================================================
# my-shell — Modular CLI Environment Bootstrapper (Resilient & Summarized)
# =============================================================================
set -u  # not using -e here, we handle errors ourselves

# -----------------------------------------------------------------------------
#  Load utilities
# -----------------------------------------------------------------------------
if [ -f "lib/00_utils.sh" ]; then
  source "lib/00_utils.sh"
else
  echo "[FATAL] Missing lib/00_utils.sh"
  exit 1
fi

info "🚀 Starting full environment bootstrap..."
echo ""

# -----------------------------------------------------------------------------
#  Summary Data
# -----------------------------------------------------------------------------
BACKUP_DIR=""
SSH_KEY_PATH=""
GPG_KEY_PATH="$HOME/.gnupg"
GIT_CONFIG_PATH="$HOME/.gitconfig"
FONT_NAME="MesloLGS NF"
BAT_THEME=""
AWS_CONFIG_DIR="$HOME/.aws"
AWS_PROFILES=()
STARSHIP_STATUS="Disabled"
FAILED_MODULES=()

# -----------------------------------------------------------------------------
#  Run each numbered module (01_*.sh, etc.)
# -----------------------------------------------------------------------------
MODULES=$(find lib -maxdepth 1 -type f -name "[0-9][0-9]_*.sh" ! -name "_*.sh" | sort)

for module in $MODULES; do
  base=$(basename "$module")
  [[ "$base" == "00_utils.sh" ]] && continue

  info "▶ Running module: $base"

  # Run each module in its own environment (bash subshell)
  bash -e "$module"
  status=$?

  if [ $status -ne 0 ]; then
    warn "⚠️  Module failed: $base (exit $status)"
    FAILED_MODULES+=("$base")
  else
    success "✅ Completed: $base"
  fi

  # Capture summary data
  case "$base" in
    01_brew.sh)
      BACKUP_DIR=$(ls -td "$HOME/.setup_backups"/backup_* 2>/dev/null | head -n 1 || echo "")
      ;;
    04_starship.sh)
      STARSHIP_STATUS="Enabled (Git/Non-Git auto-switch)"
      ;;
    05_bat.sh)
      if [ -f "$HOME/.config/bat/config" ]; then
        BAT_THEME=$(grep -i "theme" "$HOME/.config/bat/config" | awk '{print $3}' || echo "Unknown")
      else
        BAT_THEME="TwoDark"
      fi
      ;;
    06_git_setup.sh)
      SSH_KEY_PATH="$HOME/.ssh/id_ed25519"
      ;;
    08_aws.sh)
      if [ -d "$AWS_CONFIG_DIR" ]; then
        AWS_PROFILES=($(grep '^\[profile ' "$AWS_CONFIG_DIR/config" | sed -E 's/^\[profile (.*)\]/\1/'))
      fi
      ;;
  esac

  echo ""
done

# -----------------------------------------------------------------------------
#  Final Summary
# -----------------------------------------------------------------------------
info "───────────────────────────────────────────────"
info "✅ SETUP SUMMARY"
info "───────────────────────────────────────────────"
printf "📦 Backups:          %s\n" "${BACKUP_DIR:-None}"
printf "🔐 SSH Key:          %s\n" "${SSH_KEY_PATH:-None}"
printf "🔑 GPG Key:          %s\n" "${GPG_KEY_PATH:-None}"
printf "🧱 Git Config:       %s\n" "${GIT_CONFIG_PATH:-None}"
printf "💡 Font:             %s\n" "${FONT_NAME}"
printf "🚀 Starship:         %s\n" "${STARSHIP_STATUS}"
printf "🧩 Bat Theme:        %s\n" "${BAT_THEME:-TwoDark}"
echo ""

if [ -d "$AWS_CONFIG_DIR" ]; then
  info "☁️ AWS CLI SETUP"
  info "───────────────────────────────────────────────"
  printf "📁 Config Directory: %s\n" "$AWS_CONFIG_DIR"
  printf "🧾 Config File:      %s\n" "$AWS_CONFIG_DIR/config"
  printf "🔑 Credentials File: %s\n" "$AWS_CONFIG_DIR/credentials"
  printf "🧩 Profiles Created: %s\n" "${AWS_PROFILES[*]:-None}"
  printf "🌍 Default Output:   json\n"
  echo ""
  info "To update credentials later:"
  echo "  aws configure --profile <profile>"
  echo ""
  info "Manual edit locations:"
  echo "  - $AWS_CONFIG_DIR/config"
  echo "  - $AWS_CONFIG_DIR/credentials"
  echo ""
  info "🔁 Profile Switching: Enabled"
  echo "   → Use 'aws-switch' to choose a profile (fzf picker)"
  echo "   → Use 'aws-whoami' to verify active credentials"
  echo ""
fi

if [ ${#FAILED_MODULES[@]} -gt 0 ]; then
  warn "⚠️ Some modules failed:"
  printf '   - %s\n' "${FAILED_MODULES[@]}"
else
  success "🎉 All modules executed successfully."
fi

echo ""
info "───────────────────────────────────────────────"
info "💡  IMPORTANT: Set your terminal font manually!"
info "───────────────────────────────────────────────"
echo ""
echo "Starship uses Nerd Font icons. To display them correctly:"
echo ""
echo "  1️⃣  Open your terminal preferences"
echo "  2️⃣  Change the font to:  ${FONT_NAME}"
echo "  3️⃣  Restart your terminal session"
echo ""
echo "You can verify glyph support with this command:"
echo "  echo '         '"
echo ""
echo "If icons appear correctly, your setup is complete ✅"
echo ""
success "Setup complete. Reload your shell:"
echo "   source ~/.zshrc"
echo ""