\
    # my-shell-v3

[![Lint](https://github.com/jbull79/my-shell/actions/workflows/lint.yml/badge.svg)](https://github.com/jbull79/my-shell/actions/workflows/lint.yml)

    Modular, repeatable CLI environment bootstrap for macOS/Linux.

    ## Quick Start
    ```bash
    git clone <your-repo-url>.git my-shell-v3
    cd my-shell-v3
    # optional: copy overrides
    cp config/.env.local.example config/.env.local
    # edit config/.env.local as needed
    bash install.sh
    ```

    ## How it Works
    - Loads `config/defaults.env` and optional `config/.env.local`
    - Sources all scripts in `lib/` in **lexical order**
    - Skips any file starting with `_`
    - Shared logging lives in `lib/00_utils.sh`

    ## Adding Modules
    - Drop a new `NN_name.sh` into `lib/` (e.g., `10_kubectl.sh`)
    - Use `_name.sh` to keep a disabled module checked in

    ## AWS
    - Multi-profile interactive setup with validation + dummy fallback
    - Helper aliases: `aws-profiles`, `aws-switch`, `aws-whoami`
    - Starship shows current profile with color-coded aliases

    ## Datadog (optional)
    - Installs `datadogpy`, `@datadog/datadog-ci`, optional `ddtrace`
    - Adds env vars + aliases to your `~/.zshrc`

    ## Fonts
    - Installs Meslo Nerd Font (for Starship icons)
    - Reminder section guides manual terminal font selection

    ## Linting (CI)
    GitHub Action runs:
    - ShellCheck for `*.sh`
    - markdownlint for `*.md`
    - Flake8 for Python files

    ## Revert
    Backups are created under `~/.setup_backups`. Restore manually from the latest folder if needed.
